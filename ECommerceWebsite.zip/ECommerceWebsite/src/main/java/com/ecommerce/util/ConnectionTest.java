package com.ecommerce.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionTest {
    public static void main(String[] args) {
        System.out.println("🔍 Testing database connection...");
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                System.out.println("✅ Database connection successful!");
                
                // Test query to show your tables
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SHOW TABLES");
                
                System.out.println("\n📋 Tables in your database:");
                while (rs.next()) {
                    System.out.println("- " + rs.getString(1));
                }
                
                rs.close();
                stmt.close();
            }
        } catch (Exception e) {
            System.out.println("❌ Database connection failed:");
            e.printStackTrace();
        }
    }
}
