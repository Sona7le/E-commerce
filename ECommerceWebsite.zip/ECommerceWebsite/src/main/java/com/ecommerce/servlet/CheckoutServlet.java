package com.ecommerce.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.dao.CartDAO;
import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.Cart;
import com.ecommerce.model.User;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CartDAO cartDAO;
    private OrderDAO orderDAO;
    
    public void init() {
        cartDAO = new CartDAO();
        orderDAO = new OrderDAO();
        System.out.println("✅ CheckoutServlet initialized!");
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        
        // Get cart items for review
        List<Cart> cartItems = cartDAO.getUserCart(user.getUserId());
        
        if (cartItems.isEmpty()) {
            response.sendRedirect("cart?error=Your cart is empty");
            return;
        }
        
        BigDecimal cartTotal = cartDAO.getCartTotal(user.getUserId());
        int itemCount = cartDAO.getCartItemCount(user.getUserId());
        
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("cartTotal", cartTotal);
        request.setAttribute("itemCount", itemCount);
        
        request.getRequestDispatcher("pages/checkout.jsp").forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        
        // Get form data
        String shippingAddress = request.getParameter("shippingAddress");
        String paymentMethod = request.getParameter("paymentMethod");
        
        if (shippingAddress == null || shippingAddress.trim().isEmpty()) {
            response.sendRedirect("checkout?error=Please provide shipping address");
            return;
        }
        
        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            paymentMethod = "Cash on Delivery";
        }
        
        // Create order
        int orderId = orderDAO.createOrder(user.getUserId(), shippingAddress, paymentMethod);
        
        if (orderId > 0) {
            System.out.println("✅ Order placed successfully for user: " + user.getUsername());
            response.sendRedirect("orders?success=Order placed successfully! Order ID: " + orderId);
        } else {
            System.out.println("❌ Failed to place order for user: " + user.getUsername());
            response.sendRedirect("checkout?error=Failed to place order. Please try again.");
        }
    }
}
