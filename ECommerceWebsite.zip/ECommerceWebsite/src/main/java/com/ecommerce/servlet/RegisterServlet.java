package com.ecommerce.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.dao.UserDAO;
import com.ecommerce.model.User;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;
    
    public void init() {
        userDAO = new UserDAO();
        System.out.println("✅ RegisterServlet initialized!");
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        System.out.println("📄 RegisterServlet: Showing register page");
        request.getRequestDispatcher("pages/register.jsp").forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String fullName = request.getParameter("fullName");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        
        System.out.println("📝 Registration attempt for: " + username);
        
        // Validation
        if (username == null || email == null || password == null || fullName == null ||
            username.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty() || fullName.trim().isEmpty()) {
            request.setAttribute("error", "Please fill in all required fields!");
            request.getRequestDispatcher("pages/register.jsp").forward(request, response);
            return;
        }
        
        // Check if username already exists
        if (userDAO.usernameExists(username)) {
            request.setAttribute("error", "Username already exists! Please choose a different one.");
            request.getRequestDispatcher("pages/register.jsp").forward(request, response);
            return;
        }
        
        // Create new user
        User user = new User(username, email, password, fullName);
        user.setPhone(phone);
        user.setAddress(address);
        
        boolean isRegistered = userDAO.registerUser(user);
        
        if (isRegistered) {
            System.out.println("✅ Registration successful for: " + username);
            response.sendRedirect("login?success=Registration successful! Please login with your new account.");
        } else {
            System.out.println("❌ Registration failed for: " + username);
            request.setAttribute("error", "Registration failed. Please try again.");
            request.getRequestDispatcher("pages/register.jsp").forward(request, response);
        }
    }
}
