package com.ecommerce.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.model.User;

@WebServlet("/orders")
public class OrdersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private OrderDAO orderDAO;
    
    public void init() {
        orderDAO = new OrderDAO();
        System.out.println("✅ OrdersServlet initialized!");
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        
        String orderIdParam = request.getParameter("orderId");
        
        if (orderIdParam != null) {
            // Show specific order details
            int orderId = Integer.parseInt(orderIdParam);
            Order order = orderDAO.getOrderById(orderId);
            List<OrderItem> orderItems = orderDAO.getOrderItems(orderId);
            
            if (order != null && order.getUserId() == user.getUserId()) {
                request.setAttribute("order", order);
                request.setAttribute("orderItems", orderItems);
                request.getRequestDispatcher("pages/order-details.jsp").forward(request, response);
            } else {
                response.sendRedirect("orders?error=Order not found or access denied");
            }
        } else {
            // Show user's order list
            List<Order> orders = orderDAO.getUserOrders(user.getUserId());
            request.setAttribute("orders", orders);
            request.getRequestDispatcher("pages/orders.jsp").forward(request, response);
        }
    }
}
