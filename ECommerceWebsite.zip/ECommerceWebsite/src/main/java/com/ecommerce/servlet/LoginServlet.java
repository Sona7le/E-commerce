package com.ecommerce.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.dao.UserDAO;
import com.ecommerce.model.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;
    
    public void init() {
        userDAO = new UserDAO();
        System.out.println("✅ LoginServlet initialized!");
    }
    
    // Handle GET request - Show login page
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        System.out.println("📄 LoginServlet: Showing login page");
        request.getRequestDispatcher("pages/login.jsp").forward(request, response);
    }
    
    // Handle POST request - Process login
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        System.out.println("🔐 Login attempt for: " + username);
        
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("error", "Please enter both username and password!");
            request.getRequestDispatcher("pages/login.jsp").forward(request, response);
            return;
        }
        
        User user = userDAO.loginUser(username, password);
        
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getUserId());
            
            System.out.println("✅ Login successful for: " + user.getUsername());
            response.sendRedirect("dashboard");
        } else {
            System.out.println("❌ Login failed for: " + username);
            request.setAttribute("error", "Invalid username or password!");
            request.getRequestDispatcher("pages/login.jsp").forward(request, response);
        }
    }
}
