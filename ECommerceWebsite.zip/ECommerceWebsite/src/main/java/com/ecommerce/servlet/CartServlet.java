package com.ecommerce.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.dao.CartDAO;
import com.ecommerce.model.Cart;
import com.ecommerce.model.User;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CartDAO cartDAO;
    
    public void init() {
        cartDAO = new CartDAO();
        System.out.println("✅ CartServlet initialized!");
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        
        // Get user's cart items
        List<Cart> cartItems = cartDAO.getUserCart(user.getUserId());
        BigDecimal cartTotal = cartDAO.getCartTotal(user.getUserId());
        int itemCount = cartDAO.getCartItemCount(user.getUserId());
        
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("cartTotal", cartTotal);
        request.setAttribute("itemCount", itemCount);
        
        request.getRequestDispatcher("pages/cart.jsp").forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("add".equals(action)) {
            // Add item to cart
            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = 1; // Default quantity
            
            if (request.getParameter("quantity") != null) {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            }
            
            boolean added = cartDAO.addToCart(user.getUserId(), productId, quantity);
            
            if (added) {
                response.sendRedirect("cart?success=Item added to cart successfully!");
            } else {
                response.sendRedirect("products?error=Failed to add item to cart");
            }
            
        } else if ("update".equals(action)) {
            // Update cart quantity
            int cartId = Integer.parseInt(request.getParameter("cartId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            if (quantity > 0) {
                cartDAO.updateCartQuantity(cartId, quantity);
                response.sendRedirect("cart?success=Cart updated successfully!");
            } else {
                response.sendRedirect("cart?error=Invalid quantity");
            }
            
        } else if ("remove".equals(action)) {
            // Remove item from cart
            int cartId = Integer.parseInt(request.getParameter("cartId"));
            
            boolean removed = cartDAO.removeFromCart(cartId);
            
            if (removed) {
                response.sendRedirect("cart?success=Item removed from cart");
            } else {
                response.sendRedirect("cart?error=Failed to remove item");
            }
            
        } else {
            // Default action - show cart
            doGet(request, response);
        }
    }
}
