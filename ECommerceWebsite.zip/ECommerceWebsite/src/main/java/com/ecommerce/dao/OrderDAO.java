package com.ecommerce.dao;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.util.DatabaseConnection;

public class OrderDAO {
    
    // Create new order from cart
    public int createOrder(int userId, String shippingAddress, String paymentMethod) {
        String orderSql = "INSERT INTO orders (user_id, total_amount, shipping_address, order_status, payment_method) " +
                         "SELECT ?, SUM(c.quantity * p.price), ?, 'PENDING', ? " +
                         "FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
        
        String getOrderIdSql = "SELECT LAST_INSERT_ID() as order_id";
        
        String orderItemsSql = "INSERT INTO order_items (order_id, product_id, quantity, price) " +
                              "SELECT ?, c.product_id, c.quantity, p.price " +
                              "FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
        
        String clearCartSql = "DELETE FROM cart WHERE user_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction
            
            try {
                // 1. Create order
                try (PreparedStatement orderStmt = conn.prepareStatement(orderSql)) {
                    orderStmt.setInt(1, userId);
                    orderStmt.setString(2, shippingAddress);
                    orderStmt.setString(3, paymentMethod);
                    orderStmt.setInt(4, userId);
                    orderStmt.executeUpdate();
                }
                
                // 2. Get the created order ID
                int orderId = 0;
                try (PreparedStatement getIdStmt = conn.prepareStatement(getOrderIdSql);
                     ResultSet rs = getIdStmt.executeQuery()) {
                    if (rs.next()) {
                        orderId = rs.getInt("order_id");
                    }
                }
                
                // 3. Create order items
                try (PreparedStatement itemsStmt = conn.prepareStatement(orderItemsSql)) {
                    itemsStmt.setInt(1, orderId);
                    itemsStmt.setInt(2, userId);
                    itemsStmt.executeUpdate();
                }
                
                // 4. Clear user's cart
                try (PreparedStatement clearStmt = conn.prepareStatement(clearCartSql)) {
                    clearStmt.setInt(1, userId);
                    clearStmt.executeUpdate();
                }
                
                conn.commit(); // Commit transaction
                System.out.println("✅ Order created successfully with ID: " + orderId);
                return orderId;
                
            } catch (SQLException e) {
                conn.rollback(); // Rollback on error
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error creating order: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // Get user's orders
    public List<Order> getUserOrders(int userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.full_name, u.email FROM orders o " +
                     "JOIN users u ON o.user_id = u.user_id WHERE o.user_id = ? " +
                     "ORDER BY o.order_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setOrderStatus(rs.getString("order_status"));
                order.setShippingAddress(rs.getString("shipping_address"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setUserName(rs.getString("full_name"));
                order.setUserEmail(rs.getString("email"));
                orders.add(order);
            }
            
            System.out.println("✅ Retrieved " + orders.size() + " orders for user " + userId);
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting user orders: " + e.getMessage());
            e.printStackTrace();
        }
        
        return orders;
    }
    
    // Get order details with items
    public Order getOrderById(int orderId) {
        String sql = "SELECT o.*, u.full_name, u.email FROM orders o " +
                     "JOIN users u ON o.user_id = u.user_id WHERE o.order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setOrderStatus(rs.getString("order_status"));
                order.setShippingAddress(rs.getString("shipping_address"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setUserName(rs.getString("full_name"));
                order.setUserEmail(rs.getString("email"));
                return order;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting order by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    // Get order items
    public List<OrderItem> getOrderItems(int orderId) {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT oi.*, p.product_name, p.image_url, (oi.quantity * oi.price) as total_price " +
                     "FROM order_items oi JOIN products p ON oi.product_id = p.product_id " +
                     "WHERE oi.order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                OrderItem item = new OrderItem();
                item.setItemId(rs.getInt("item_id"));
                item.setOrderId(rs.getInt("order_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setQuantity(rs.getInt("quantity"));
                item.setPrice(rs.getBigDecimal("price"));
                item.setProductName(rs.getString("product_name"));
                item.setProductImage(rs.getString("image_url"));
                item.setTotalPrice(rs.getBigDecimal("total_price"));
                items.add(item);
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting order items: " + e.getMessage());
            e.printStackTrace();
        }
        
        return items;
    }
    
    // Update order status
    public boolean updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET order_status = ? WHERE order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, orderId);
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("✅ Updated order status to: " + status);
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("❌ Error updating order status: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // Get all orders (for admin)
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.full_name, u.email FROM orders o " +
                     "JOIN users u ON o.user_id = u.user_id ORDER BY o.order_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setOrderStatus(rs.getString("order_status"));
                order.setShippingAddress(rs.getString("shipping_address"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setUserName(rs.getString("full_name"));
                order.setUserEmail(rs.getString("email"));
                orders.add(order);
            }
            
            System.out.println("✅ Retrieved " + orders.size() + " total orders");
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting all orders: " + e.getMessage());
            e.printStackTrace();
        }
        
        return orders;
    }
}
