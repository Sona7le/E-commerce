package com.ecommerce.dao;

import com.ecommerce.model.User;

public class UserDAOTest {
    public static void main(String[] args) {
        System.out.println("🧪 Testing UserDAO...");
        
        UserDAO userDAO = new UserDAO();
        
        // Test 1: Create a test user
        User testUser = new User("testuser123", "test@email.com", "password123", "Test User");
        testUser.setPhone("1234567890");
        testUser.setAddress("123 Test Street");
        
        // Test 2: Register the user
        System.out.println("\n1. Testing user registration...");
        boolean isRegistered = userDAO.registerUser(testUser);
        
        if (isRegistered) {
            System.out.println("✅ User registration successful!");
            
            // Test 3: Login with the same user
            System.out.println("\n2. Testing user login...");
            User loggedInUser = userDAO.loginUser("testuser123", "password123");
            
            if (loggedInUser != null) {
                System.out.println("✅ User login successful!");
                System.out.println("User details: " + loggedInUser);
            } else {
                System.out.println("❌ User login failed!");
            }
            
        } else {
            System.out.println("❌ User registration failed!");
        }
    }
}
