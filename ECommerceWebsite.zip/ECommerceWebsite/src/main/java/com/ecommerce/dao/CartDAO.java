package com.ecommerce.dao;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.ecommerce.model.Cart;
import com.ecommerce.util.DatabaseConnection;

public class CartDAO {
    
    // Add item to cart
    public boolean addToCart(int userId, int productId, int quantity) {
        String checkSql = "SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?";
        String updateSql = "UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?";
        String insertSql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            
            // Check if item already exists in cart
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, userId);
                checkStmt.setInt(2, productId);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    // Item exists, update quantity
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, quantity);
                        updateStmt.setInt(2, userId);
                        updateStmt.setInt(3, productId);
                        int rowsAffected = updateStmt.executeUpdate();
                        System.out.println("✅ Updated cart item quantity");
                        return rowsAffected > 0;
                    }
                } else {
                    // Item doesn't exist, add new
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                        insertStmt.setInt(1, userId);
                        insertStmt.setInt(2, productId);
                        insertStmt.setInt(3, quantity);
                        int rowsAffected = insertStmt.executeUpdate();
                        System.out.println("✅ Added new item to cart");
                        return rowsAffected > 0;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error adding to cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // Get user's cart items with product details
    public List<Cart> getUserCart(int userId) {
        List<Cart> cartItems = new ArrayList<>();
        String sql = "SELECT c.cart_id, c.user_id, c.product_id, c.quantity, c.added_at, " +
                     "p.product_name, p.price, p.image_url, (c.quantity * p.price) as total_price " +
                     "FROM cart c JOIN products p ON c.product_id = p.product_id " +
                     "WHERE c.user_id = ? ORDER BY c.added_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Cart cart = new Cart();
                cart.setCartId(rs.getInt("cart_id"));
                cart.setUserId(rs.getInt("user_id"));
                cart.setProductId(rs.getInt("product_id"));
                cart.setQuantity(rs.getInt("quantity"));
                cart.setAddedAt(rs.getTimestamp("added_at"));
                cart.setProductName(rs.getString("product_name"));
                cart.setProductPrice(rs.getBigDecimal("price"));
                cart.setProductImage(rs.getString("image_url"));
                cart.setTotalPrice(rs.getBigDecimal("total_price"));
                cartItems.add(cart);
            }
            
            System.out.println("✅ Retrieved " + cartItems.size() + " items from cart");
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting cart items: " + e.getMessage());
            e.printStackTrace();
        }
        
        return cartItems;
    }
    
    // Update cart item quantity
    public boolean updateCartQuantity(int cartId, int quantity) {
        String sql = "UPDATE cart SET quantity = ? WHERE cart_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, quantity);
            stmt.setInt(2, cartId);
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("✅ Updated cart quantity");
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("❌ Error updating cart quantity: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // Remove item from cart
    public boolean removeFromCart(int cartId) {
        String sql = "DELETE FROM cart WHERE cart_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("✅ Removed item from cart");
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("❌ Error removing from cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // Get cart total for user
    public BigDecimal getCartTotal(int userId) {
        String sql = "SELECT SUM(c.quantity * p.price) as total FROM cart c " +
                     "JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                BigDecimal total = rs.getBigDecimal("total");
                return total != null ? total : BigDecimal.ZERO;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting cart total: " + e.getMessage());
            e.printStackTrace();
        }
        
        return BigDecimal.ZERO;
    }
    
    // Get cart item count
    public int getCartItemCount(int userId) {
        String sql = "SELECT SUM(quantity) as count FROM cart WHERE user_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("count");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error getting cart count: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
}
